This is Basically a Library for People who want to simplify the process of taking input in different formats and from different file types in Python.

Install Instructions:

Windows:

pip install input_simple

Mac/Linux:

sudo pip3 install input_simple
